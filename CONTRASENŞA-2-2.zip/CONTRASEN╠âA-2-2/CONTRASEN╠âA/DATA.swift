//
//  DATOS.swift
//  CONTRASEÑA
//
//  Created by Usuario invitado on 19/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation
struct Data {
        var UserName : String
        var Name : String
        var Password : String
        var Email: String
    }

