//
//  SecondViewController.swift
//  CONTRASEÑA
//
//  Created by Usuario invitado on 19/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var User: UITextField!
    
    
    @IBOutlet weak var Password: UITextField!
    
    @IBAction func GoIn(_ sender: UIButton) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        }
        
        
 
    }

    //override func didReceiveMemoryWarning() {
        //super.didReceiveMemoryWarning()

    //}

