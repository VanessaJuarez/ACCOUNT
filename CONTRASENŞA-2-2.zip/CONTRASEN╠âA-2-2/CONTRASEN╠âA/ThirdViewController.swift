//
//  ThirdViewController.swift
//  CONTRASEÑA
//
//  Created by Usuario invitado on 19/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    @IBOutlet weak var UserR: UITextField!
    
    @IBOutlet weak var NameR: UITextField!
    
    @IBOutlet weak var PasswordR: UITextField!
   
    @IBAction func Save(_ sender: UIButton) {
        let defaults = UserDefaults.standard
        
        if let value1 = UserR.text{
            defaults.set(value1, forKey: "data")
        }
        if let value2 = NameR.text{
            defaults.set(value2, forKey: "data")
        }
        if let value3 = PasswordR.text{
            defaults.set(value3, forKey: "data")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let defaults = UserDefaults.standard
        
        if let data1 = defaults.object(forKey: "data") as? String{
            UserR.text = data1
        }
        if let data2 = defaults.object(forKey: "data") as? String{
            UserR.text = data2
        }
        if let data3 = defaults.object(forKey: "data") as? String{
            UserR.text = data3
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    


}
